package com.example.assign3;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.backendless.servercode.annotation.Async;

public class CreateLeaner extends AppCompatActivity {
    private View mProgressView;
    private View create_learner_form;
    private TextView tvLoad;


    EditText etName, etSurname, etGrade;
    TextView tvCode;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_leaner);

        create_learner_form = findViewById(R.id.create_learner_form);
        mProgressView = findViewById(R.id.login_progress);
        tvLoad = findViewById(R.id.tvLoad);

        etName = findViewById(R.id.etName);
        etSurname = findViewById(R.id.etSurname);
        etGrade = findViewById(R.id.etGrade);
        tvCode = findViewById(R.id.tvCode);
        btnSubmit = findViewById(R.id.btnSubmit);

        tvCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    startActivity(new Intent(CreateLeaner.this, MainActivity.class));
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etGrade.getText().toString().isEmpty()||
                        etSurname.getText().toString().isEmpty()||
                        etName.getText().toString().isEmpty())
                {
                    Toast.makeText(CreateLeaner.this, "Enter all fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Leaner leaner = new Leaner();
                    leaner.setName(etName.getText().toString().trim());
                    leaner.setSurname(etSurname.getText().toString().trim());
                    leaner.setGrade(etGrade.getText().toString().trim());
                    leaner.setSchoolEmail(ApplicationClass.user.getEmail());
                    String barcode = getIntent().getStringExtra("barcode");
                    tvCode.setText(barcode);
                    leaner.setCode(tvCode.getText().toString().trim());

                    tvLoad.setText("Creating new learner... please wait...");
                    showProgress(true);

                    Backendless.Persistence.save(leaner, new AsyncCallback<Leaner>() {
                        @Override
                        public void handleResponse(Leaner response) {
                            Toast.makeText(CreateLeaner.this, "Learner successfully saved!", Toast.LENGTH_SHORT).show();
                            etName.setText(null);
                            etSurname.setText(null);
                            etGrade.setText(null);
                            tvCode.setText(null);
                            showProgress(false);
                        }

                        @Override
                        public void handleFault(BackendlessFault fault) {
                            Toast.makeText(CreateLeaner.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                            showProgress(false);
                        }
                    });
                }
            }
        });
    }
    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            create_learner_form.setVisibility(show ? View.GONE : View.VISIBLE);
            create_learner_form.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    create_learner_form.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });

            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            create_learner_form.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }
}