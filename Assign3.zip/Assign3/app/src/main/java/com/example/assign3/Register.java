package com.example.assign3;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.google.android.material.textfield.TextInputLayout;

public class Register extends AppCompatActivity {
    private View mProgressView;
    private View register_form;
    private TextView tvLoad;
    TextInputLayout txtInputName,txtInputReSecondaryPassword,txtInputSecondaryPassword,txtInputSchoolEmail;
    Button btnRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //code for the progress bar
        register_form = findViewById(R.id.register_form);
        mProgressView = findViewById(R.id.login_progress);
        tvLoad = findViewById(R.id.tvLoad);

        txtInputName = findViewById(R.id.txtInputName);
        txtInputSchoolEmail = findViewById(R.id.txtInputSchoolEmail);
        txtInputSecondaryPassword = findViewById(R.id.txtInputSecondaryPassword);
        txtInputReSecondaryPassword = findViewById(R.id.txtInputReSecondaryPassword);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtInputName.getEditText().getText().toString().trim().isEmpty()||
                        txtInputReSecondaryPassword.getEditText().getText().toString().trim().isEmpty() ||
                        txtInputSecondaryPassword.getEditText().getText().toString().trim().isEmpty() ||
                        txtInputSchoolEmail.getEditText().getText().toString().trim().isEmpty())
                {
                    Toast.makeText(Register.this, "Enter all fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if( txtInputSecondaryPassword.getEditText().getText().toString().trim().matches(txtInputReSecondaryPassword.getEditText().getText().toString().trim()))
                    {
                        String name = txtInputName.getEditText().getText().toString().trim();
                        String emailSchool = txtInputSchoolEmail.getEditText().getText().toString().trim();
                        String primary = txtInputSecondaryPassword.getEditText().getText().toString().trim();
                        String secondary =txtInputReSecondaryPassword.getEditText().getText().toString().trim();

                        BackendlessUser usr = new BackendlessUser();

                        usr.setEmail(emailSchool);
                        usr.setProperty("emailSchool",emailSchool);
                        usr.setPassword(primary);
                        usr.setProperty("secondary",secondary);



                        Backendless.UserService.register(usr, new AsyncCallback<BackendlessUser>() {
                            @Override
                            public void handleResponse(BackendlessUser response) {
                                Toast.makeText(Register.this, "Successfully registered", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(Register.this, Login.class));
                                Register.this.finish();
                            }

                            @Override
                            public void handleFault(BackendlessFault fault) {
                                Toast.makeText(Register.this, "Error: "+fault.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                        Intent intent = new Intent(Register.this, Menu.class);
                        intent.putExtra("schoolName", name);
                        startActivity(intent);
                        Register.this.finish();
                    }
                    else
                    {
                        Toast.makeText(Register.this, "please make sure you password matches", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            register_form.setVisibility(show ? View.GONE : View.VISIBLE);
            register_form.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    register_form.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });

            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            register_form.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }
}