package com.example.assign3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class RecordScreening extends AppCompatActivity {

    TextView tvNameAndSurnameResults, tvGradeResults, tvCodeResults;
    CheckBox cbLast14Days, cbInContact, cbSymptoms;
    EditText etTemperature;
    Button btnSubmint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_screening);

        tvNameAndSurnameResults = findViewById(R.id.tvNameAndSurnameResults);
        tvGradeResults = findViewById(R.id.tvGradeResults);
        tvCodeResults = findViewById(R.id.tvCodeResults);
        cbLast14Days = findViewById(R.id.cblast14Days);
        cbInContact = findViewById(R.id.cbInContact);
        cbSymptoms = findViewById(R.id.cbSymptoms);
        etTemperature = findViewById(R.id.etTemperature);
        btnSubmint = findViewById(R.id.btnSubmint);

        btnSubmint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}